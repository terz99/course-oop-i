/*
CH08-320142
a5 p1.cpp
Dushan Terzikj
d.terzikj@jacobs-university.de
*/
#include <iostream>
#include "fraction.h"

using namespace std;

int main()
{
    Fraction a, b, c;
    cin >> a >> b >> c;

    cout << a << endl;
    cout << b << endl;
    cout << c << endl;
}